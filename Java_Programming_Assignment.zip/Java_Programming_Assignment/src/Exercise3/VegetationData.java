package Exercise3;
//Importing all the required libraries
import java.io.BufferedReader;//This line imports the Buffered reader
import java.io.FileReader;//This line imports the FileReader . It looks weird to use the buffered reader and filereader but this is simply because using both file and buffered reader just makes the process a lot faster.
import java.io.IOException;//This line imports the IOException
import java.util.*;//This line imports all the classes and libraries of the java.util class because of the .* at the end of the statement

public class VegetationData {// This line creates the vegetationData class
    public final int MAX_HEIGHT = 500;//This is the maximum height of the screen array
    public final int MAX_WIDTH = 1000;//This is the maximum width of the screen array
    private final int[][] screenArray;//This line creates an array called screenArray that stores the vegetation intensity at each coordinate
    private final TreeMap<Double, TreeMap<Double, Integer>> coordinates = new TreeMap<>();//This line creates a double key TreeMap with the longitude as the first key and the latitude being the second key and the percentageTreeCover being the value

    public VegetationData(String filePath) throws NumberFormatException, IOException {//This line is the constructor for VegetationData ,this reads the data from the file and initializes the arrays
        this.screenArray = new int[this.MAX_HEIGHT][this.MAX_WIDTH];//This line creates a new screenArray with the given dimensions

        BufferedReader vegetationDataCollector = new BufferedReader(new FileReader(filePath));//This line creates a new buffered reader object and also another filereader object inside of it

        String line;//This line is creating an empty variable that stores the values that are read by the buffered reader
        while ((line = vegetationDataCollector.readLine()) != null) {//This while loop will iterate through the whole code as long as there is another line in the code
            String[] values = line.split("\\s+");//This line of code makes sure that each character seperated by a space will be split
            double longitude = Double.parseDouble(values[0]);//This line stores the value of the longitude as a double
            double latitude = Double.parseDouble(values[1]);//This line stores the value of the latitude as a double
            int percentageTreeCover = Integer.parseInt(values[2]);//This line stores the value of the percentageTreeCover as an int

            int x = (int) ((longitude + 180.0) / 360 * this.MAX_WIDTH);//Since we cannot store negative values we need to convert the longitude values into a positive number, that is what this formula does
            int y = (int) ((90 - latitude) / 200 * this.MAX_HEIGHT);//Since we cannot store negative values we need to convert the latitude values into a positive number, that is what this formula does

            this.screenArray[y][x] = percentageTreeCover;//This line stores the intensity at the correct value of longitude AND latitude

            TreeMap<Double, Integer> map = coordinates.getOrDefault(longitude, new TreeMap<>());//This line basically creates map inside a map with coordinates being the outer map and longitude being the outer key and the latitude being the inner key for the percentageTreeCover and the inner map is a treemap called map.
            map.put(latitude, percentageTreeCover);//This line adds the value of the latitude and percentageTreeCover to a TreeMap called map
            coordinates.put(longitude, map);//This line puts the value of the longitude and the map onto the treemap called coordinates
        }

    }

    public int getFromArray(int longitude, int latitude) {//This function retrieves the value from the array by using the latitude and longitude as the x and y coordinates to locate the respective value of the percentageTreeCover
        return this.screenArray[latitude][longitude];
    }

    public int getFromMap(double longitude, double latitude) {//This statement checks whether there is a longitude key for the latitude and if not it will find the closest key, and it will update the longitude variable accordingly
        // If the coordinates map does not contain the given longitude key,
        // find the closest key and update the longitude variable accordingly
        if (!coordinates.containsKey(longitude)) {//This line gets all the longitudes in the map
            List<Double> longitudes = new ArrayList<>(coordinates.keySet());// This statement does a binary search for the index of the closest longitude key
            int index = Collections.binarySearch(longitudes, longitude);
            if (index < 0) { // if the value is 0 it means that the key has been found if not it means that the key has not been found
                index = -index - 1;
            }
            if (index == longitudes.size()) { // This line uses the last key if the given longitude is larger than all other keys
                index--;
            } else if (index > 0) { // Compare the distances between the given longitude and the two adjacent keys
                double lowerDiff = Math.abs(longitudes.get(index - 1) - longitude);
                double upperDiff = Math.abs(longitudes.get(index) - longitude);
                if (upperDiff < lowerDiff) {// If the upper key is closer, use it as the closest key
                    index--;
                }
            }
            longitude = longitudes.get(index);// Update the longitude variable to the closest key
        }

        // Get the map of latitudes and vegetation intensities for the closest longitude key
        Map<Double, Integer> latitudeMap = coordinates.get(longitude);

        // Get all the latitudes in the latitude map
        List<Double> latitudes = new ArrayList<>(latitudeMap.keySet());
        // Binary search for the index of the closest latitude key
        int index = Collections.binarySearch(latitudes, latitude);
        if (index < 0) { // Key not found, get the insertion point
            index = -index - 1;
        }
        if (index == latitudes.size()) { // Use the last key if the given latitude is larger than all keys
            index--;
        } else if (index > 0) { // This statement compares the distances between the given latitude and the two adjacent keys
            double lowerDiff = Math.abs(latitudes.get(index - 1) - latitude);
            double upperDiff = Math.abs(latitudes.get(index) - latitude);// This line will check ff the upper key is closer, and it uses it as the closest key
            if (upperDiff < lowerDiff) {
                index--;
            }
        }
        double closestLatitude = latitudes.get(index);// This line gets the vegetation intensity for the closest latitude key
        return latitudeMap.get(closestLatitude);
    }
}
