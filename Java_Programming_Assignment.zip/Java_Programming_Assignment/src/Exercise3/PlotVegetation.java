package Exercise3;

import javax.swing.*;//This line imports the javax.swing library the * represents the fact that all the classes and interfaces will be imported from the javax.swing library.This is used to create GUI(Graphical User Interface) components
import java.awt.*;//This line imports the javax.awt library the * represents the fact that all the classes and interfaces will be imported from the javax.awt library.

class PlotVegetation extends JComponent {//Creating a class called Plotvegetation that extends JComponent
    //The next two lines contain 2 private boolean instance variables that control display options
    //Now the
    private boolean useColour = true;//This indicates whether to use color or not
    private boolean useMap = true;//This indicates whether to use the Map or not
    private final VegetationData newVegetationData; //This creates a VegetationData object

    // The lines 14-24 is a Constructor for the PlotVegetation class that takes three parameters
    public PlotVegetation(VegetationData newVegetationData, boolean useColour, boolean useMap) throws NumberFormatException {

        this.newVegetationData = newVegetationData;// This line assigns the newVegetationData parameter to the instance variable
        this.useColour = useColour;// This line assigns the useColour parameter to the instance variable
        this.useMap = useMap;//This line assigns the useMap parameter to the instance variable
    }
    private Color blend(Color c0, Color c1) {
        double totalAlpha = (double) (c0.getAlpha() + c1.getAlpha()); //This line calculates the total alpha of the two colors
        double weight0 = (double) c0.getAlpha() / totalAlpha;// This line calculates the weights of each color based on their alpha values
        double weight1 = (double) c1.getAlpha() / totalAlpha;

        // The next 3 lines calculate the red, green, and blue values of the blended color
        double r = weight0 * (double) c0.getRed() + weight1 * (double) c1.getRed();
        double g = weight0 * (double) c0.getGreen() + weight1 * (double) c1.getGreen();
        double b = weight0 * (double) c0.getBlue() + weight1 * (double) c1.getBlue();

        double a = (double) Math.max(c0.getAlpha(), c1.getAlpha());// The alpha value of the blended color is set to the maximum

        return new Color((int) r, (int) g, (int) b, (int) a);// This line creates and returns a new Color object with the blended values
    }


    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g); // Calls the paintComponent method of the parent class to ensure proper painting of the component.

        //This method checks whether useMap is true, if it is it will loop through each pixel in the component and set its color based on the corresponding longitude and latitude.
        if (useMap) {
            for (int i = 0; i < getHeight(); i++) {
                for (int j = 0; j < getWidth(); j++) {
                    double longitude = ((double) j / getWidth()) * 360 - 180; //This calculates the longitude corresponding to the current x-coordinate.
                    double latitude = 90 - ((double) i / getHeight()) * 180; // This line calculates the latitude corresponding to the current y-coordinate.
                    int value = newVegetationData.getFromMap(longitude, latitude); // This line gets the vegetation data value at the given longitude and latitude.

                    // The following if statement checks whether the useColour is true,then the following lines of code will set the color of the pixel based on the vegetation value.
                    if (this.useColour) {
                        if (value == 0) {
                            g.setColor(Color.white);
                        } else if (value == 254) {
                            g.setColor(Color.blue);
                        } else {
                            g.setColor(this.blend(new Color(150, 75, 0, 255 * (1 - value / 100)), new Color(0, 255, 0, 255 * value / 100)));
                        }
                        // The following else statement checks whether the useColour is false, if it is it will set the color of the pixel based on the vegetation value as a grayscale value.
                    } else {
                        if (value == 0) {
                            g.setColor(Color.black);
                        } else if (value == 254) {
                            g.setColor(Color.white);
                        } else {
                            g.setColor(new Color(0, 0, 0, 255 * value / 100));
                        }
                    }
                    g.fillRect(j, i, 1, 1); // Fill the current pixel with the chosen color.
                }
            }
            // The following lines of code check whether useMap is false, if it is they will loop through each pixel in the component and set its color based on the corresponding x and y indices in the vegetation data array.
        } else {
            for (int i = 0; i < getHeight(); i++) {
                for (int j = 0; j < getWidth(); j++) {
                    int value = newVegetationData.getFromArray(j, i); // Gets the vegetation data value at the current x and y indices.

                    // The following lines check whether useColour is true, then they will set the color of the pixel based on the vegetation value.
                    if (this.useColour) {
                        if (value == 0) {
                            g.setColor(Color.white);
                        } else if (value == 254) {
                            g.setColor(Color.blue);
                        } else {
                            g.setColor(this.blend(new Color(150, 75, 0, 255 * (1 - value / 100)), new Color(0, 255, 0, 255 * value / 100)));
                        }
                        // The following lines of code check whether useColour is false, if it is it will set the color of the pixel based on the vegetation value as a grayscale value.
                    } else {
                        if (value == 0) {
                            g.setColor(Color.black);
                        } else if (value == 254) {
                            g.setColor(Color.white);
                        } else {
                            g.setColor(new Color(0, 0, 0, 255 * value / 100));
                        }
                    }
                    g.fillRect(j, i, 1, 1); // This line fills the current pixel with the chosen color.
                }
            }
        }
    }

}
