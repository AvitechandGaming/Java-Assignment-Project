package Exercise3;
//Importing all the required libraries
import javax.swing.*;//This line imports the javax.swing library the * represents the fact that all the classes and interfaces will be imported from the javax.sing library.This is used to create GUI(Graphical User Interface) components
import java.io.IOException;

public class MainEx3 {//This line creates a public class called MainEx3
    private static int screenWidth = 1000;//This line sets the screen width
    private static int screenHeight = 500;//This line sets the screen height
    public MainEx3() {//This line contains the default constructor for the MainEx3 class
    }

    public static void main(String[] arguments) throws NumberFormatException, IOException {//This is the main method of the program that also contains some error handling in the form of numberFormatException and IOException. IO stands for input/output.

        VegetationData newvegetationData = new VegetationData("E:\\Coding Files for Java\\Java_Programming_Assignment\\src\\Exercise3\\vegetationData.csv");//Creating a new instance of the VegetationData class which is called newvegetationData by passing the .csv file as an argument/parameter

        PlotVegetation vegetationDataPlotter = new PlotVegetation(newvegetationData, true, true);//This line of code creates a new instance of the class plotVegetation called vegetationDataPlotter and the parameters passed include the vegetationDataObject(newvegetationData),whether the map should be colored(useColour) and whether the hashmap should be used or not(useMap)

        JFrame frame = new JFrame("Exercise 3 Map");//This line creates a new JFrame object called frame and the parameter passed is a string that is the title of the window
        frame.setSize(screenWidth, screenHeight);//This line sets the size of the JFrame to the values of screenWidth and screenHeight
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//This line basically closes the application when the JFrame is closed
        frame.add(vegetationDataPlotter);//Adding the vegetationDataPlotter object to the JFrame
        frame.setVisible(true);//If this is not set to true then the JFrame will not be visible
    }
}
