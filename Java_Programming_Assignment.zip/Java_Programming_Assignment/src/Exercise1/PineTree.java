package Exercise1;

public class PineTree extends Tree {//This line shows that the PineTree class is a subclass of the tree Class(Parent Class)

    public PineTree(int height) {//This initializes the height of the tree via the constructor
        super(height);
    }

    @Override// This statement is not actually required, but it improves the readability of the code
    public String getSegment(int returnTypeOfSegment) {//The 'returnTypeOfSegment' variable changes with 'i' as we have done in the toString method
        if (getHeight() == 0){
            return "     ";  // Just returns the width of the tree with 2 spaces the if the height of the tree is zero
        }
        else if (getHeight() == returnTypeOfSegment) {
            return " ^   ";// returns the '^' to symbolize the top of the tree, this is returned only when the getHeight method returns the same value as the returnTypeOfSegment. The extra 2 spaces are to make the trees look spaced out
        }
        else {
            return "/|\\  ";//This returned as the base and middle of the tree. When this is invoked only '/|\' is returned as one of the '\' is used to escape the other '\'. The extra 2 spaces are to make the trees look spaced out
        }
    }
}
//Acknowledgements
// I have used these sources to help me understand along with the slides from the lectures and respective topics
//https://www.geeksforgeeks.org/overriding-in-java/

