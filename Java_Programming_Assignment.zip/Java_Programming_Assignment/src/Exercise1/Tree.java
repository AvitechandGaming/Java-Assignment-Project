package Exercise1;

public abstract class Tree{
    private int height;// Creating a private variable called height that will store the height of the tree
    public Tree (int height){
        this.height = height; //Initializing the variable height via a constructor
    }

    public int getHeight() { //Creating a method called getHeight that returns the value of the height of the tree
        return height;
    }

    public abstract String getSegment(int returnTypeOfSegment);//Creating an abstract method that returns a String

    @Override// This statement is not actually required, but it improves the readability of the code
    public String toString(){
        StringBuilder treeCreator = new StringBuilder();//We have created a new StringBuilder Object to create the Tree
        for (int i = height ; i > 0; i -= 1){//Here this for loop works by reducing the value of i by 1 each time until it reaches 0(this 'i' variable is used in the 'returnTypeOfSegment' variable
            treeCreator.append(getSegment(i));
        }
        return treeCreator.toString();//Returns the built string which is the Tree
    }
}

//Acknowledgements
// I have used these sources to help me understand along with the slides from the lectures and respective topics
//https://www.javatpoint.com/understanding-toString()-method
//https://www.geeksforgeeks.org/overriding-in-java/