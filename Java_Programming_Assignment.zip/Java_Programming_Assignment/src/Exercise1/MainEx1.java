package Exercise1;

public class MainEx1 {
    public static void main(String[] args) {
        // create a forest with n(1st parameter) trees, maximum height of y(second parameter)
        Forest forest = new Forest(40, 10);
        System.out.println(forest);//Printing out the forest
        System.out.println("This is the Forest");
    }
}
