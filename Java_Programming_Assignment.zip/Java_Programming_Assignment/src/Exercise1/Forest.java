package Exercise1;
//Here we are importing all the required libraries
import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public class Forest {
    Random rn = new Random();//Creating a new random object
    ArrayList<Tree> collectionOfTrees = new ArrayList<>();//Creating a new Arraylist called collectionOfTrees that stores the dataType of Tree

    public Forest(int numberOfTrees, int maximumHeight) {//The constructor for forest that takes in two parameters
        int treeType = 3;//There are 3 types of trees available
        for (int i = 1; i <= numberOfTrees; i += 1) {//This loops through the number of trees that has been specified
            int randomTree = ThreadLocalRandom.current().nextInt(0, treeType + 1);// This line generates the tree type that should be returned
            int randomTreeHeight = ThreadLocalRandom.current().nextInt(0, maximumHeight + 1);//This generates the maximum height of the tree within the range of 0 to whatever value is specified in the maximum height
            Tree tree;
            //The following if, else and else-if statements tell the program of which tree to create and adds the trees to the arraylist
            // Here in all the constructors of the type of trees we pass the 'randomTreeHeight' as a parameter because the getSegment method requires the getHeight() method which would return this height
            if (randomTree == 1) {
                tree = new Bamboo(randomTreeHeight);//
                collectionOfTrees.add(tree);
            } else if (randomTree == 2) {
                tree =new PineTree(randomTreeHeight);
                collectionOfTrees.add(tree);
            } else {
                tree = new BroadleafTree(randomTreeHeight);
                collectionOfTrees.add(tree);
            }
        }
    }
    private int maximumHeight() {// This returns the height of the highest possible tree in the forest
        int x = 0;
        for (Tree tree : collectionOfTrees) {
            if (tree.getHeight() > x) {
                x = tree.getHeight();
            }
        }
        return x;
    }

    @Override// This statement is not actually required, but it improves the readability of the code
    public String toString() {
        StringBuilder sb = new StringBuilder();//Creating a new String builder object
        for (int i = maximumHeight(); i > 0; i -= 1) {//This for loop loops through each tree in the forest
            for (Tree tree : collectionOfTrees) {
                if (tree.getHeight() >= i) {
                    sb.append(tree.getSegment(i));//This just adds the segment of the tree if the height of the tree that has been specified is not reached
                }
                else {
                    sb.append("     ");//If the tree's height is less than the maximum height then add spaces until the tree reaches the maximum height
                }
            }
            sb.append("\n");
        }
        return sb.toString();//Returning the StringBuilder as a String
    }
}
//Acknowledgements
// I have used these sources to help me understand along with the slides from the lectures and respective topics
//https://www.geeksforgeeks.org/overriding-in-java/