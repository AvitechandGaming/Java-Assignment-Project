package Exercise2;

public class Tree {
    public String location;//Creating a variable to store the location
    public String name;//Creating a variable to store the name
    public double height;//Creating a variable of type 'int' to store the height of the tree
    public String age; //Creating a variable of type 'int' to store the age of the tree

    public Tree(String location,String name,String age,double height) {//This line defines a constructor that takes in the location,name height and age of a tree
        this.location = location;
        this.name = name;
        this.height = height;
        this.age = age;}
    //Creating the 4 getter methods to retrieve the 4 variables which are location,name,height and age
    public String getLocation(){
        return location;
    }
    public String getName(){
        return name;
    }
    public double getHeight(){
        return height;
    }
    public String getAge(){
        return age;
    }

}