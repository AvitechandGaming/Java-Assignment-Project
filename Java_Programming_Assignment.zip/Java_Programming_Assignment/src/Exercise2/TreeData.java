package Exercise2;
//Importing all the required libraries
import java.io.*;
import java.util.*;

public class TreeData {//Creating a public class called TreeData

    private final List<Tree> collectionOfTrees;//Creating a private list

    public TreeData(String filePath) {//The constructor of the treeData class will take a parameter that is the filepath of the .csv file
        collectionOfTrees = new ArrayList<>();// This line initializes the list of trees.
        /*The try catch block below is intended to handle errors*/
        try {
            Scanner treeDataCollector = new Scanner(new File(filePath));// First this line creates a new scanner block and then this line opens the file specified by filePath
            treeDataCollector.nextLine();//Since we don't need the header of the file we skip it and that is what this line does
            while (treeDataCollector.hasNextLine()) {// This while loop loops through the csv file as long as there is content on the next line
                String line = treeDataCollector.nextLine();// This line reads a line from the file
                String[] attributes = line.split(",");// This line Splits the line into its components using a comma(,) as the delimiter
                /* The next 4 lines extract the attributes from the components*/
                String borough = attributes[1];
                String treeName = attributes[2];
                String ageGroup = attributes[3];
                double height = Double.parseDouble(attributes[4]);
                Tree tree = new Tree(borough, treeName, ageGroup, height);// This line creates a new tree object with the extracted attributes
                collectionOfTrees.add(tree);//This line adds the current tree to the list called 'collectionOfTrees'
            }
            treeDataCollector.close();//This closes the Scanner object
        } catch (FileNotFoundException e) {
            System.out.println("File Not Found Exception");//If the File Not Found Exception is Caught then the message "File Not Found Exception " is printed to the console
        }
    }

    public void printTreesPerBorough() {
        Map<String, Integer> treesPerBorough = new TreeMap<>();// This line initializes a map to keep count of the number of trees per borough, I have used TreeMap instead of HashMap because it returns the names of the boroughs in alphabetical order
        for (Tree tree : collectionOfTrees) {// This for loop counts the number of trees for each borough by looping through the whole list
            String borough = tree.getLocation();//This line gets the borough for each tree
            treesPerBorough.put(borough, treesPerBorough.getOrDefault(borough, 0) + 1);//This code adds the value of 1 to every borough when a tree's getLocation value returns that value, if there are no trees in the borough then the line adds a new entry to treesPerBorough
        }
        /*This for loop prints out the number of trees in each borough*/
        for (Map.Entry<String, Integer> entry : treesPerBorough.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }
        System.out.println("________________________________________________________________________________________________");
    }

    public void printMostCommonAge() {
        Map<String, Integer> treesPerAgeRange = new HashMap<>();// This line initializes a map to keep count of the number of trees per age range
        /* The next 2 lines initialize variables to keep track of the most common age range and its count*/
        String mostCommonAgeRange = null;//We set the mostCommonAgeRange value to null in order to initialize it
        int maxCount = 0;
        for (Tree tree : collectionOfTrees) {// This for loop counts the number of trees for each borough by looping through the whole list
            String ageRange = tree.getAge();//This line contains a method that returns the age range of the tree
            int count = treesPerAgeRange.getOrDefault(ageRange, 0) + 1;//This line will increase the count of 1 to the trees according to the certain age group
            treesPerAgeRange.put(ageRange, count);//This line puts the count of trees belonging to a particular age group into the hash map created on line 46
            /*The next 3 lines Update the most common age range */
            if (count > maxCount) {
                mostCommonAgeRange = ageRange;
                maxCount = count;
            }
        }
        System.out.println("Most common age range is " + mostCommonAgeRange + " with a count of: " + maxCount);
        System.out.println("________________________________________________________________________________________________");

    }


    public void printLeastCommonAge() {
        Map<String, Integer> treesPerAgeRange = new HashMap<>();// This creates a map to keep track of the number of trees in each age range
        for (Tree tree : collectionOfTrees) {// This for loop counts the number of trees for each borough by looping through the whole list
            String ageRange = tree.getAge();// This line gets the age range of the current tree
            treesPerAgeRange.put(ageRange, treesPerAgeRange.getOrDefault(ageRange, 0) + 1);//This line increments the count for the current age range in the map
        }

        List<Map.Entry<String, Integer>> ageRangeCounts = new ArrayList<>(treesPerAgeRange.entrySet());//This line creates a list of entries from the map, so that we can sort it
        ageRangeCounts.sort(Map.Entry.comparingByValue());//This line sorts the entries in ascending order
        Map.Entry<String, Integer> leastCommonAgeRangeEntry = ageRangeCounts.get(0);//This line gets the first entry which will be the leastCommonAge
        System.out.println("Least common age range is " + leastCommonAgeRangeEntry.getKey() +  " with a count of: " + leastCommonAgeRangeEntry.getValue());
        System.out.println("________________________________________________________________________________________________");

    }

    public void printAverageHeightPerTreeName() {
        Map<String, List<Double>> heightsByName = new HashMap<>();// This line creates a map to keep track of the heights of trees with each name
        for (Tree tree : collectionOfTrees) {//This for loop iterates over each tree in the list collectionOfTrees
            String name = tree.getName();//This line gets the name of the current tree
            Double height = tree.getHeight();//This line gets the height of the current tree
            List<Double> heights = heightsByName.getOrDefault(name, new ArrayList<>());//If the tree's name is present this line will add the height, in case it is not present then it will create a new empty list
            heights.add(height);//This line adds the height of the current tree to the list
            heightsByName.put(name, heights);//This adds the updated/new list to the map
        }
        for (Map.Entry<String, List<Double>> entry : heightsByName.entrySet()) {// This for loop iterates over each entry in the map (each name and its associated list of heights)
            String name = entry.getKey();//This line gets the name of the tree from the entry
            List<Double> heights = entry.getValue();//This line gets the height of the tree from the entry
            double sum = 0;//We are initializing the variable called sum (This will then be divided by the total number of trees )
            /* This for loop iterates over each height in the list and add it to the sum */
            for (Double height : heights) {
                sum += height;
            }
            double averageHeight = sum / heights.size();// This line calculates the average height by dividing the sum by the number of heights in the list
            System.out.println("Average height for " + name + ": " + averageHeight);
        }
        System.out.println("________________________________________________________________________________________________");

    }
    public void printAverageHeightForTree(String name) { //This method takes in a string as a parameter but still returns a void
        List<Double> heights = new ArrayList<>();//This line creates a new list to store the heights of all the trees with the given parameters
        for (Tree tree : collectionOfTrees) {//This for loop iterates over each tree in the list collectionOfTrees
            if (tree.getName().equals(name)) {//This if loop is entered only when the input String is the same as the value that the tree.getName() function returns, this is checked by the .equals() method
                heights.add(tree.getHeight());//This adds the height of the tree that has been matched to the list
            }
        }
        if (heights.isEmpty()) {//If the list is empty that means that there is no tree with the name specified
            System.out.println("Unknown tree.");
            return;//The code will still work without this statement, but removing it could potentially result in a wrong value being calculated as the code can still be executed if a name is entered that does not match a tree
        }
        double sum = 0;// We initialize a variable called sum of type double
        for (Double height : heights) {// This for loop basically adds the heights of all the trees in the list together by iterating and adding over the whole list
            sum += height;
        }
        double averageHeight = sum / heights.size();// This line calculates the average height by dividing the sum by the number of heights in the list
        System.out.println("Average height for trees with name " + name + ": " + averageHeight);
        System.out.println("________________________________________________________________________________________________");

    }
}
//Acknowledgements:
// I have used these sources to help me understand along with the slides from the lectures and respective topics
//https://docs.oracle.com/en/java/javase/17/docs/api/java.base/java/util/Scanner.html
//https://stackoverflow.com/questions/tagged/java+scanner
//https://www.tutorialspoint.com/java/util/java_util_scanner.htm
//https://www.geeksforgeeks.org/scanner-class-in-java/
//https://www.journaldev.com/768/java-scanner-class
//https://docs.oracle.com/en/java/javase/17/docs/api/java.base/java/util/HashMap.html
//https://www.tutorialspoint.com/java/java_hashmap_class.htm
//https://stackoverflow.com/questions/tagged/java+hashmap
//https://www.geeksforgeeks.org/java-util-hashmap-in-java/
//https://www.javatpoint.com/filenotfoundexception-in-java