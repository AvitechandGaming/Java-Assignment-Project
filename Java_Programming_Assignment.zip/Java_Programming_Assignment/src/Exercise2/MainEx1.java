package Exercise2;
//Importing all the required libraries
import java.util.Scanner;

public class MainEx1 {

    public static void main(String[] args)  {
        String fileName = "E:\\Coding Files for Java\\Java_Programming_Assignment\\src\\Exercise2\\treesPruned.csv";//This is the path of the file
        TreeData treeData = new TreeData(fileName);// Creating an instance of the TreeData Class
        Scanner input= new Scanner(System.in);// Creating a new Scanner object to read the user's input
        while (true) {// This while loop will loop until the user enter the word "quit"
            System.out.println("Please enter:\n1 to print number of trees per borough\n2 to print most common tree age\n3 to print least common tree age\n4 to print average height per tree name\n5 to enter tree name and print average height\nquit to quit");
            String inputStream = input.nextLine();//This stores the value entered to a String
            switch (inputStream) {//We are using enhanced switch cases
                case "1" -> treeData.printTreesPerBorough();//For when user enters 1
                case "2" -> treeData.printMostCommonAge();//For when user enters 2
                case "3" -> treeData.printLeastCommonAge();//For when user enters 3
                case "4" -> treeData.printAverageHeightPerTreeName();//For when user enters 4
                case "5" -> {//For when user enters 5
                    System.out.println("Please enter the name of a tree,(first letter in capital)");
                    String treeName = input.nextLine();
                    treeData.printAverageHeightForTree(treeName);
                }
                case "quit" -> {
                    System.out.println("GoodBye");
                    System.exit(0);//For when user enters "quit"
                }
                default -> System.out.println("Invalid entry");
            }
        }
    }
}
//Acknowledgements:
// I have used these sources to help me understand along with the slides from the lectures and respective topics
//https://docs.oracle.com/en/java/javase/17/docs/api/java.base/java/nio/file/Path.html
//https://www.tutorialspoint.com/java_nio/java_nio_path.htm
//https://stackoverflow.com/questions/tagged/java+path
//https://www.baeldung.com/java-path
//https://www.journaldev.com/24607/java-nio-path

