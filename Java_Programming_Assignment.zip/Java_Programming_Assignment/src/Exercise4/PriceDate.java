package Exercise4;

public class PriceDate implements Comparable<PriceDate> {//This line creates a public class called PriceDate that implements Comparable for the PriceDate Class
    /*In the next 3 lines we declare the dat,month and year which are all of datatype int */
    private final int day;
    private final int month;
    private final int year;

    public PriceDate(int day, int month, int year) {//This is the constructor method for the PriceDate class
        this.day = day;
        this.month = month;
        this.year = year;
    }

    public int getDay() {//This function returns the day i.e. this is a getter method
        return day;
    }

    public int getMonth() {//This function returns the month i.e. this is a getter method
        return month;
    }

    public int getYear() {//This function returns the Year i.e. this is a getter method
        return year;
    }

    @Override// This statement is not actually required, but it improves the readability of the code
    public int compareTo(PriceDate other) {//Here we declare the method compareTo which takes in an argument of type PriceDate
        int yearDiff = this.year - other.year;//This line will return the difference between the years
        /*If the difference between the years is not zero then the difference between the years is returned*/
        if (yearDiff != 0) {
            return yearDiff;
        }
        int monthDiff = this.month - other.month;//This line will return the difference between the months
        /*If the difference between the months is not zero then the difference between the years is returned*/
        if (monthDiff != 0) {
            return monthDiff;
        }
        return this.day - other.day;//If the month and the year are the same then the day is used to compare the two PriceDates to each other
    }

    @Override// This statement is not actually required, but it improves the readability of the code
    public String toString() {//This line overrides the toString() method to return the String in the format of dd-mm-yy
        //The next 15 lines is something which is known as "enhanced switch case"
        String monthStr = switch (this.month) {//Since both the date and year can just be returned we don't have any switch cases for those two, but for the month since our input will be an int, but we would need to return a word, hence we have these enhanced switch cases
            case 1 -> "Jan";
            case 2 -> "Feb";
            case 3 -> "Mar";
            case 4 -> "Apr";
            case 5 -> "May";
            case 6 -> "Jun";
            case 7 -> "Jul";
            case 8 -> "Aug";
            case 9 -> "Sep";
            case 10 -> "Oct";
            case 11 -> "Nov";
            case 12 -> "Dec";
            default -> "Not a valid value";//This is a default case which is returned if the none of the other cases are met, for example if the month is entered as 100
        };
        return String.format("%02d-%s-%04d", this.day, monthStr, this.year );//Returning the String in the required format
    }
}
