package Exercise4;

import java.io.*;
import java.util.*;

public class TreePriceData {
    private final ArrayList<TreePrice> treePrices = new ArrayList<>();//This line creates an arraylist to store the treeprices
    ArrayList<TreePrice> finalList = new ArrayList<>();//This line creates a new ArrayList to store values

    //constructor to read the file, split it and add it to an ArrayList
    public TreePriceData() throws IOException {//This Io exception is present to do the exception handling
        BufferedReader dataCollector = new BufferedReader(new FileReader("E:\\Coding Files for Java\\Java_Programming_Assignment\\src\\Exercise4\\treePrices.csv"));//The buffered reader takes in a parameter which is passed as a file reader which itself takes the path as the parameter
        String line;//This line creates a new variable of string type called String
        boolean firstLine = true;//This basically skips the first line
        while ((line = dataCollector.readLine()) != null) {//This while loop iterates through the code until there are no lines left
            if (firstLine) {
                firstLine = false;
                continue; // Skip first line with column headers
            }
            String[] fields = line.split(",");//This makes sure that the data is split with the regex is ",".
            int day = Integer.parseInt(fields[0].substring(0, 2));//This takes the regex of "," and further splits the date into day month and year
            int month = getMonth(fields[0].substring(3, 6));//This takes the regex of "," and further splits the date into day month and year
            int year = Integer.parseInt(fields[0].substring(7));//This takes the regex of "," and further splits the date into day month and year
            PriceDate priceDate = new PriceDate(day, month, year);//This line creates a new PriceDate object
            double nominalPrice = Double.parseDouble(fields[1]);//This stores the value of the nominalPrice
            double realPrice = Double.parseDouble(fields[2]);//This stores the value of the realPrice
            TreePrice treePrice = new TreePrice(realPrice, nominalPrice, priceDate);//This creates a new TreePrice object
            treePrices.add(treePrice);//This adds the treeprice to list
        }
        dataCollector.close();//This closes the reader
        Collections.sort(treePrices);//This sorts the treePrice
    }
    private int getMonth(String monthStr) {//This method basically takes in a String and return the value as an int
        String[] months = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
        for (int i = 1; i < months.length; i++) {
            if (months[i].equals(monthStr)) {
                return i ;
            }
        }
        return -1;
    }



    public ArrayList<TreePrice> sortTreePrices() {//This method sorts out the TreePrices according to their year
        ArrayList<TreePrice> firstResult = new ArrayList<>();
        for (TreePrice treePrice : treePrices) {//This for loop iterates through the treePrices list
            int year = treePrice.getPriceDate().getYear();//The next 4 lines of code are there to deal with issues concering 20th century dates being regarded higher than 21st century dates
            if (year >= 86 && year <= 99) {
                firstResult.add(treePrice);
            }
        }
        ArrayList<TreePrice> secondResult = new ArrayList<>();
        for (TreePrice treePrice : treePrices) {
            int year = treePrice.getPriceDate().getYear();
            if (year >= 00 && year <= 22) {
                secondResult.add(treePrice);
            }
        }
        finalList.addAll(firstResult);
        finalList.addAll(secondResult);
        return finalList;//This line returns the finalList
    }



    public ArrayList<TreePrice> getTreePrices() {//This getter method returns the respective array
        return finalList;
    }
}
