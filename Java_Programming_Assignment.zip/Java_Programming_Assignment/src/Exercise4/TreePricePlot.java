package Exercise4;
//These statements import all the required libraries
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;
import java.util.List;

public class TreePricePlot extends JComponent {//This line creates a class TreePricePlot which extends JComponent
    private final TreePriceData treePriceData;//This line creates a private final variable of TreePriceData

    public TreePricePlot(TreePriceData treePriceData) {//This is the constructor of the TreePricePlot class which takes in a parameter of treePriceData
        this.treePriceData = treePriceData;//This line initializes the treePriceData with the parameter object
        addMouseListener(new MouseAdapter() {//This line adds the mouselistener which displays the closest click for the closest prices
            @Override//This statement is not actually necessary, but we use it to improve readability
            public void mouseClicked(MouseEvent e) {// This invokes the displayClosestPrices method with the X coordinate of mouse click
                displayClosestPrices(e.getX());
            }
        });
    }

    //Main paint method to draw the graph
    @Override
    public void paintComponent(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;// This line creates a Graphics2D object

        List<TreePrice> treePrices = treePriceData.getTreePrices();// This line gets a list of TreePrice objects from treePriceData

        double maxPrice = Double.MIN_VALUE;// This line initializes the maximum price as the smallest possible value
        double minPrice = Double.MAX_VALUE;// This line initializes the minimum price as the largest possible value
        for (TreePrice treePrice : treePrices) {//This for loop iterates through each TreePrice object in treePrices
            double nominalPrice = treePrice.getNominalPrice();// This line gets the nominal price from the current TreePrice object
            double realPrice = treePrice.getRealPrice();// This line gets the real price from the current TreePrice object
            maxPrice = Math.max(maxPrice, Math.max(nominalPrice, realPrice));// This line updates the maximum price with the larger value of maximum price, nominal price, and real price
            minPrice = Math.min(minPrice, Math.min(nominalPrice, realPrice));// This line updates the minimum price with the smaller value of minimum price, nominal price, and real price
        }

        // Set the color and font for the nominal price line
        g2d.setColor(Color.BLACK);//This sets the color of the line representing the nominal prices to black
        g2d.setFont(new Font("Arial", Font.ITALIC, 10));//This line sets the font for the nominal prices

        // Plot the nominal price line
        int x1 = 50;
        int y1 = (int) ((maxPrice - treePrices.get(0).getNominalPrice()) / (maxPrice - minPrice) * (getHeight() - 100)) + 50;
        for (int i = 0; i < treePrices.size(); i++) {
            int x2 = (int) ((double) i / (treePrices.size() - 1) * (getWidth() - 100)) + 50;
            int y2 = (int) ((maxPrice - treePrices.get(i).getNominalPrice()) / (maxPrice - minPrice) * (getHeight() - 100)) + 50;
            g2d.drawLine(x1, y1, x2, y2);
            x1 = x2;
            y1 = y2;


            AffineTransform savedTransform = g2d.getTransform();//This line below saves the current graphics state

            double radians = Math.toRadians(90);// These two lines below rotate the graphics object by 90 degrees around the current point
            g2d.rotate(radians, x1, getHeight() - 25);

            String dateString = treePrices.get(i).getPriceDate().toString();// These two lines  will print the date beneath each data point at the rotated angle of 90
            g2d.drawString(dateString, x1 - 25, getHeight() - 25);

            // Restore the saved graphics state
            g2d.setTransform(savedTransform);
        }

        // Set the color and font for the real price line
        g2d.setColor(Color.GREEN);//This sets the color of the line representing the real prices to green
        g2d.setFont(new Font("Arial", Font.PLAIN, 10));//This line sets the font for the real prices

        // Plot the real price line
        x1 = 50;//This is the starting x coordinate of the line
        y1 = (int) ((maxPrice - treePrices.get(0).getRealPrice()) / (maxPrice - minPrice) * (getHeight() - 100)) + 50;//This line calculates the starting Y coordinate of the line
        for (int i = 0; i < treePrices.size(); i++) {// This for loop iterates through each TreePrice object in treePrices
            int x2 = (int) ((double) i / (treePrices.size() - 1) * (getWidth() - 100)) + 50;//This is the final x coordinate of the line
            int y2 = (int) ((maxPrice - treePrices.get(i).getRealPrice()) / (maxPrice - minPrice) * (getHeight() - 100)) + 50; //This is the final y coordinate of the line
            g2d.drawLine(x1, y1, x2, y2);//This line basically draws the line
            x1 = x2;//These two lines are for matching the points
            y1 = y2;

        }
    }

    private void displayClosestPrices(int x) {//This method basically displays the closes point to where the mouse listener has been activated
        List<TreePrice> treePrices = treePriceData.getTreePrices();

        int closestIndex = 0; // This line finds the index of the closest data point to the clicked point
        double closestDistance = Double.MAX_VALUE;
        for (int i = 0; i < treePrices.size(); i++) {
            int pointX = (int) ((double) i / (treePrices.size() - 1) * (getWidth() - 100)) + 50;//This formula is used to determine which value should be triggered by pointX
            double distance = Math.abs(pointX - x);
            if (distance < closestDistance) {
                closestIndex = i;
                closestDistance = distance;
            }
        }

        double closestNominalPrice = treePrices.get(closestIndex).getNominalPrice();//This line gets the closest nominal price
        double closestRealPrice = treePrices.get(closestIndex).getRealPrice();//This line gets the closest real price

        System.out.println("Closest nominal price: " + closestNominalPrice);
        System.out.println("Closest real price: " + closestRealPrice);
    }

}

