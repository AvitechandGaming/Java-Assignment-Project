package Exercise4;

//These 2 statements are importing all the libraries
import javax.swing.*;
import java.io.IOException;

public class MainEx4 {//This line creates the MainEx4 class that contains psvm
    public static void main(String[] args) throws IOException {//The Io exception is for exception handling
        TreePriceData tpd = new TreePriceData();//This line creates a new TreePriceData Object
        tpd.sortTreePrices();//This line sorts the tree prices according to their date
        TreePricePlot plot = new TreePricePlot(tpd);//This creates a new TreePricePlot Object

        JFrame jf = new JFrame();//This line creates a new JFrame Object
        jf.getContentPane().add(plot);//This adds the plot object to the JFrame
        jf.setSize(1000, 500);//This line sets the size of the jFrame
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);// This line sets the default close operation of the JFrame
        jf.setLocationRelativeTo(null);// This line sets the location of the JFrame relative to the parent container
        jf.setVisible(true);//This is required in order to make sure that the graph is visible
    }
}