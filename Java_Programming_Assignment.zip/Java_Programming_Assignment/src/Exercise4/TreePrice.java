package Exercise4;

public class TreePrice implements Comparable<TreePrice> {// In this line we are creating a public class called TreePrice which implements comparable
    private double realPrice;//Creating a private variable called realPrice of double datatype
    private double nominalPrice;//Creating a private variable called lPrice of double datatype
    private PriceDate priceDate;//Creating a private variable called realPrice of double datatype

    public TreePrice(double realPrice, double nominalPrice, PriceDate priceDate) {//This is the constructor for the TreePrice class
        this.realPrice = realPrice;
        this.nominalPrice = nominalPrice;
        this.priceDate = priceDate;
    }

    public double getRealPrice() {//This is a getter method that gets the RealPrice
        return realPrice;
    }

    public double getNominalPrice() {//This is a getter method that gets the NominalPrice
        return  nominalPrice;
    }

    public PriceDate getPriceDate() {//This is a getter method that gets the PriceData
        return priceDate;
    }

    @Override
    public int compareTo(TreePrice treePrice) {
        return this.priceDate.compareTo(treePrice.priceDate);//This statement basically returns a negative int, positive int or zero depending on whether one value is greater than or just equal to each other
    }

    @Override
    public String toString() {
        return String.format("%s Nominal: %.1f Real: %.1f", this.priceDate, this.nominalPrice, this.realPrice);//This returns the values of the nominal and real prices in the required format
    }
}
